# Geslaagde GEM-X CPU-proef met gebruikersvideo

Alleen het interval 0–2 seconden van `jaap beweegt.mp4` is verwerkt: 60 frames
op 30 Hz. De volledige bronvideo van 8,33 seconden is niet geanalyseerd.

Totale wandtijd: **730.34 seconden (12 minuten 10 seconden)**.
Video-inferentie inclusief normalisatie: 702.79 seconden.
Piek-RSS van procesboom, gesampled om de 50 ms: **4.44 GiB**.
Gedeelde pagina's kunnen dubbel tellen; korte pieken kunnen gemist worden.
De modeldownloads vallen buiten deze tijd. Importeren, hashes en uitvoerexport
vallen binnen de totale tijd. De overlay is na deze meting gemaakt.

Hardware: INTEL(R) XEON(R) PLATINUM 8573C, Linux, affiniteit beperkt tot twee logische CPU's,
PyTorch 2.10.0+cpu. Geen GPU-uitvoering. Dit is geen Windows- of laptopbenchmark.

| Fase | Seconden |
| --- | ---: |
| Video normaliseren | 9.89 |
| Detectie en tracking | 89.28 |
| ViTPose 77 gewrichten | 395.46 |
| Camerabeweging | 7.14 |
| Body Pose-features | 200.64 |
| Temporele Body Motion | 0.39 |
| SOMA-FK en export | 10.76 |

Voorbereiding vóór de eerste fase: ongeveer 16,8 seconden.
De beeldmodellen domineren de tijd. De temporele Motion-forward zelf duurt
ongeveer 0,39 seconde; de volledige RGB-pipeline is veel zwaarder.

## Bestanden

- `jaap-motion-overlay.mp4`: oorspronkelijke clip met daarop de geprojecteerde
  3D-gewrichten uit het temporele Motion-resultaat. Dit is een visuele controle,
  geen onafhankelijke nauwkeurigheidsmeting.
- `raw_motion.pt`: ongewijzigde oorspronkelijke uitvoer van `run_body_video`,
  inclusief ruwe camera-/wereldparameters, voorwaarden, tracking en cameradata.
- `kinematics.npz`: 77 gewrichtsposities en globale segmentrotatiematrices,
  voor camera- en wereldruimte; segmentnamen en tijdstippen.
- `kinematics.json`: eenheden, assen en matrixconventies. Posities in meters,
  tijd in seconden; camera X-rechts/Y-omlaag/Z-vooruit, wereld Y-omhoog.
  Geen automatische MuJoCo-retargeting, geen gekalibreerde wereldrichting/origin.
- `benchmark.json`: uitvoertijden, geheugen, configuratie, codecommit,
  pakketversies en SHA256s van daadwerkelijk gebruikte modelbestanden.
- `downloaded-models.json`: officiële modelrevisies en geverifieerde hashes.
- `runner.py` en `runner-provenance.json`: exacte gebruikte proefcode en hash.
- `validation.json`: controles op aantallen frames, eindige uitvoer en tracking.

Alle 60 frames hadden een waargenomen primaire track. De bestanden bevatten
60 × 77 gewrichtsposities en evenveel 3×3 segmentrotaties per ruimte. De
export controleert eindige waarden, orthogonaliteit en determinant van rotaties.
De FK-conventies zijn apart getest met echte SOMA-assets en bekende rotatie/
verplaatsing. Er is geen ground truth voor de nauwkeurigheid van deze video.

## Grenzen van deze proef

De actuele native77 Body Motion-pipeline is gebruikt. Body Pose levert uitsluitend
features; de uiteindelijke voorspelling is temporeel. Geen framewise Pose-fallback.
Optionele Contact/IK-correctie en meshweergave zijn niet uitgevoerd. Camera-intrinsics
zijn geschat; nominale meters betekenen geen gevalideerde meetnauwkeurigheid.

De hele proef slaagde met Hugging Face-offlineflags, uitgeschakelde ONNX-telemetrie
en een audit-hook die Python-netwerkverbindingen weigert; nul socketpogingen
waargenomen. Dit is geen OS-netwerkisolatietest van native libraries. Windows-
uitvoering en de CPU van de gebruiker zijn niet getest. De huidige resultaten
rechtvaardigen geen claim dat een Windows-exe klaar is.

De gelezen NVIDIA-modellicentie staat royaltyvrij gebruik toe onder voorwaarden.
De commerciële distributievoorwaarden van de externe HumanArt-detector blijven
apart te verhelderen. Het archief bevat onderzoeksuitvoer en geen modelgewichten.
